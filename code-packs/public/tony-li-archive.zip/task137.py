def p(a):
 n,m=len(a),len(a[0]);o=[[0]*m for _ in range(n)];mp={}
 [[mp.setdefault(a[i][j],[]).append((i,j))for j in range(m)if a[i][j]]for i in range(n)]
 for v,ps in mp.items():
  ps.sort();r0,c0=ps[len(ps)//2];k=abs(ps[1][0]-ps[0][0])or abs(ps[1][1]-ps[0][1])if len(ps)>1 else 0
  if k<=0:
   for i in range(len(ps)):
    for j in range(i+1,len(ps)):
     if(d:=max(abs(ps[i][0]-ps[j][0]),abs(ps[i][1]-ps[j][1]))):k=d;break
    if k:break
  k=k or 1
  for s in range(1,max(r0,n-1-r0,c0,m-1-c0)//k+1):
   r1,r2,c1,c2=r0-s*k,r0+s*k,c0-s*k,c0+s*k
   0<=r1<n and[o[r1].__setitem__(c,v)for c in range(max(0,c1),min(m,c2+1))]
   0<=r2<n and[o[r2].__setitem__(c,v)for c in range(max(0,c1),min(m,c2+1))]
   0<=c1<m and[o[r].__setitem__(c1,v)for r in range(max(0,r1),min(n,r2+1))]
   0<=c2<m and[o[r].__setitem__(c2,v)for r in range(max(0,r1),min(n,r2+1))]
  o[r0][c0]=v
 return o