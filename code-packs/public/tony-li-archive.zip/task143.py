R=range
L=len
def p(a):
    h,w=L(a),L(a[0]); t=[[1 if a[i][j] else 0 for j in R(3)] for i in R(3)]
    for r in R(h-2):
        for c in R(w-2):
            if r<1 and c<1: continue
            v=None; ok=True
            for i in R(3):
                for j in R(3):
                    x=a[r+i][c+j]
                    if t[i][j]:
                        if not x or (v is not None and x!=v): ok=False; break
                        if v is None: v=x
                    elif x: ok=False; break
                if not ok: break
            if not ok: continue
            if any(0<=r+i+di<h and 0<=c+j+dj<w and not(r<=r+i+di<r+3 and c<=c+j+dj<c+3) and a[r+i+di][c+j+dj]==v
                   for i in R(3) for j in R(3) if t[i][j] for di,dj in ((1,0),(-1,0),(0,1),(0,-1))): 
                continue
            for i in R(3):
                for j in R(3):
                    if t[i][j]: a[r+i][c+j]=5
            return a
    return a