def p(g):
 r=[R[:]for R in g];b={(i,j)for i in range(len(g))for j in range(len(g[0]))if g[i][j]==1}
 if not b:return r
 for o in[0,1]:
  c=set()
  for i,j in b:
   for x,y in[(5-i+o,j-5),(5-j+o,4-i+o),(i-5,j-4)]:
    if -5<=x<=5 and -5<=y<=5:c.add((x,y))
  v=[z for z in c if all((5-x+o,5+y)in b or not(0<=5-x+o<len(g)and 0<=5+y<len(g[0]))for x,y in[z])and all((4-y+o,5-x+o)in b or not(0<=4-y+o<len(g)and 0<=5-x+o<len(g[0]))for x,y in[z])and all((5+y,4+x)in b or not(0<=5+y<len(g)and 0<=4+x<len(g[0]))for x,y in[z])and any(0<=5-x+o<len(g)and 0<=5+y<len(g[0])and(5-x+o,5+y)in b for x,y in[z])]
  if v:
   s={(5-x+o,5+y)for x,y in v if 0<=5-x+o<len(g)and 0<=5+y<len(g[0])}|{(4-y+o,5-x+o)for x,y in v if 0<=4-y+o<len(g)and 0<=5-x+o<len(g[0])}|{(5+y,4+x)for x,y in v if 0<=5+y<len(g)and 0<=4+x<len(g[0])}
   if s==b:
    for x,y in v:
     if 0<=4+x<len(r)and 0<=4-y+o<len(r[0])and r[4+x][4-y+o]==0:r[4+x][4-y+o]=2
    break
 return r