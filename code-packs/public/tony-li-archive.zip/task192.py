def p(g,L=len,R=range):
 h,w=L(g),L(g[0])
 f=sum(g,[]);C=sorted([[f.count(k),k] for k in set(f)])[0][1]
 P=[[0,1],[0,-1],[-1,0],[1,0]]
 for r in R(h):
  for c in R(w):
   if g[r][c]==C:
    m=[]
    for y,x in P:
     if r+y>=0 and c+x>=0 and r+y<h and c+x<w:
      m+=[g[r+y][c+x]]
    if sum(m)/L(m)<max(m)/2:
     g[r][c]=0
    else: g[r][c]=max(m)
    try:
     if g[r][c+1]+g[r][c-1]==0 or g[r+1][c]+g[r-1][c]==0:g[r][c]=0
    except:pass
  if g[-1][-1]>0:
   if g[-2][-1]==0:g[-1][-1]=0
   if g[-1][-2]==0:g[-1][-1]=0
  if g[-1][10]>0 and g[-2][10]==0:g[-1][10]=0
 return g