from collections import deque
def p(w):
    def f(g, n):
        r, c = len(g), len(g[0])
        v = [[False] * c for _ in range(r)]
        b = []
        for i in range(r):
            for j in range(c):
                if g[i][j] == n and not v[i][j]:
                    cb, q = [], deque([(i, j)])
                    v[i][j] = True
                    while q:
                        cr, cc = q.popleft()
                        cb.append((cr, cc))
                        for dr, dc in [(x, y) for x in [-1, 0, 1] for y in [-1, 0, 1] if x or y]:
                            nr, nc = cr + dr, cc + dc
                            if 0 <= nr < r and 0 <= nc < c and g[nr][nc] == n and not v[nr][nc]:
                                v[nr][nc] = True
                                q.append((nr, nc))
                    b.append(cb)
        return b
    
    r, c = len(w), len(w[0])
    tb, t = f(w, 2), f(w, 5)
    tc = [i for b in tb for i in b]
    u = len({p[1] for p in tc}) < len({p[0] for p in tc})
    o = [[0] * c for _ in range(r)]
    for x, y in tc:
        o[x][y] = 2
    if not t: return o
    if len(t) == 1:
        k, j = t[0], 1 if u else 0
        l = (min(p[j] for p in k) + max(p[j] for p in k)) / 2
        t = [part for part in ([p for p in k if p[j] <= l], [p for p in k if p[j] > l]) if part]
    if len(t) < 2: return o
    z = lambda b: min(p[1 if u else 0] for p in b)
    t.sort(key=z)
    tb.sort(key=z)
    tg = 2
    for i in range(2):
        b5, b2 = t[i], tb[i]
        a, b = (1, 0) if u else (0, 1)
        m, n = min(p[a] for p in b5), max(p[a] for p in b5)
        c = [(p[b], m + n - p[a]) if u else (m + n - p[a], p[b]) for p in b5]
        d, e = min(p[a] for p in b2), max(p[a] for p in b2)
        s = (d - tg) - max(p[a] for p in c) if i == 0 else (e + tg) - min(p[a] for p in c)
        for x, y in c:
            if u:
                o[x][y + s] = 5
            else:
                o[x + s][y] = 5
    return o
