def p(g):
 h,w=len(g),len(g[0]);ac=sum(g,[]);cc={};[cc.update({c:cc.get(c,0)+1})for c in ac];bg=max(cc,key=cc.get);v=[[0]*w for _ in range(h)];o=[]
 for i in range(h):
  for j in range(w):
   if not v[i][j] and g[i][j]!=bg:
    oc=[];s=[(i,j)];col=g[i][j]
    while s:
     ci,cj=s.pop()
     if ci<0 or ci>=h or cj<0 or cj>=w or v[ci][cj] or g[ci][cj]!=col:continue
     v[ci][cj]=1;oc.append((ci,cj));s.extend([(ci+di,cj+dj)for di,dj in[(0,1),(0,-1),(1,0),(-1,0)]])
    oc and o.append(frozenset((col,pos)for pos in oc))
 sp=[obj for obj in o if len(obj)==1];pairs=[(sp[i],sp[j])for i in range(len(sp))for j in range(len(sp))if i!=j];vp=[]
 for oa,ob in pairs:
  pa,pb=next(iter(oa))[1],next(iter(ob))[1];hm,vm=pa[0]==pb[0],pa[1]==pb[1];(hm or vm)and vp.append((oa,ob))
 r=[r[:]for r in g]
 for oa,ob in vp:
  pa,pb,ca=next(iter(oa))[1],next(iter(ob))[1],next(iter(oa))[0];ai,aj,bi,bj=pa[0],pa[1],pb[0],pb[1];lp=[]
  if ai==bi:lp=[(ai,j)for j in range(min(aj,bj),max(aj,bj)+1)]
  elif aj==bj:lp=[(i,aj)for i in range(min(ai,bi),max(ai,bi)+1)]
  elif bi-ai==bj-aj:si,ei=min(ai,bi),max(ai,bi);sj=aj if ai<=bi else bj;lp=[(si+k,sj+k)for k in range(ei-si+1)]
  elif bi-ai==aj-bj:si,ei=min(ai,bi),max(ai,bi);sj=aj if ai<=bi else bj;lp=[(si+k,sj-k)for k in range(ei-si+1)]
  if lp:cp=lp[len(lp)//2];0<=cp[0]<h and 0<=cp[1]<w and r.__setitem__(cp[0],r[cp[0]][:cp[1]]+[ca]+r[cp[0]][cp[1]+1:])
 return r