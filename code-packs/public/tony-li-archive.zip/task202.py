def p(a):
    m,n=len(a),len(a[0])
    rv=[(lambda s: next(iter(s)) if len(s)<=1 else None)({x for x in r if x}) for r in a]
    cv=[(lambda s: next(iter(s)) if len(s)<=1 else None)({a[i][j] for i in range(m) if a[i][j]}) for j in range(n)]
    def g(v):
        r=[];s=0
        for i in range(1,len(v)+1):
            if i==len(v) or v[i]!=v[i-1]: r.append((s,i-1)); s=i
        return r
    if all(v is not None for v in rv) and len(set(rv))>1:
        for r0,r1 in g(rv):
            for j in range(n):
                if any(a[i][j]==0 for i in range(r0,r1+1)):
                    for i in range(r0,r1+1): a[i][j]=0
        return a
    if all(v is not None for v in cv) and len(set(cv))>1:
        for c0,c1 in g(cv):
            for i in range(m):
                if any(a[i][j]==0 for j in range(c0,c1+1)):
                    for j in range(c0,c1+1): a[i][j]=0
    return a