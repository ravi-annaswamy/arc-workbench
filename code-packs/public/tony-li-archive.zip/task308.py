def p(g):
 h,w=len(g),len(g[0]);ac=sum(g,[]);cc={};[cc.update({c:cc.get(c,0)+1})for c in ac];bg=max(cc,key=cc.get);pal=set(ac);fo=[]
 for c in pal:
  if c!=bg:oc=[(i,j)for i in range(h)for j in range(w)if g[i][j]==c];oc and fo.append(frozenset((c,pos)for pos in oc))
 if not fo:return g
 mh,mw=0,0
 for obj in fo:
  pos=[pos for col,pos in obj]
  if pos:mr,Mr,mc,Mc=min(p[0]for p in pos),max(p[0]for p in pos),min(p[1]for p in pos),max(p[1]for p in pos);oh,ow=Mr-mr+1,Mc-mc+1;mh,mw=max(mh,oh),max(mw,ow)
 ms=(mh,mw);canvas=[[bg]*mw for _ in range(mh)];no=[]
 for obj in fo:
  pos=[pos for col,pos in obj]
  if pos:mr,mc=min(p[0]for p in pos),min(p[1]for p in pos);no.append(frozenset((col,(pos[0]-mr,pos[1]-mc))for col,pos in obj))
 co=[]
 for obj in no:
  pos=[pos for col,pos in obj]
  if pos:omr,omc=max(p[0]for p in pos),max(p[1]for p in pos);os=(omr+1,omc+1);sr,sc=(ms[0]-os[0])//2,(ms[1]-os[1])//2;co.append(frozenset((col,(pos[0]+sr,pos[1]+sc))for col,pos in obj))
 for obj in co:
  for col,(r,c) in obj:0<=r<mh and 0<=c<mw and canvas.__setitem__(r,canvas[r][:c]+[col]+canvas[r][c+1:])
 return canvas