def p(g):
 h,w=len(g),len(g[0]);x=[[0 if c==9 else c for c in r]for r in g];t=[[x[j][i]for j in range(h)]for i in range(w)];m=[[max(x[i][j],t[i][j])for j in range(min(w,len(t[0])))]for i in range(min(h,len(t)))];c=h-2,w-2
 if c[0]>0 and c[1]>0:x8=[r[2:2+c[1]]for r in m[2:2+c[0]]]
 else:x8=[[]]
 x9=[r[::-1]for r in x8]
 if not x9 or not x9[0]:return m
 gh,gw=len(x9),len(x9[0]);v=[[0]*gw for _ in range(gh)];o=[]
 for i in range(gh):
  for j in range(gw):
   if not v[i][j] and x9[i][j]:
    obj=[];s=[(i,j)]
    while s:
     ci,cj=s.pop()
     if 0<=ci<gh and 0<=cj<gw and not v[ci][cj] and x9[ci][cj]:v[ci][cj]=1;obj.append((ci,cj));s.extend([(ci+di,cj+dj)for di,dj in[(0,1),(1,0),(0,-1),(-1,0)]])
    obj and o.append(obj)
 x11=sum(o,[]);x12=[(i+2,j+2)for i,j in x11];r=[r[:]for r in m]
 for i,j in x12:
  if 0<=i<len(r) and 0<=j<len(r[0]):oi,oj=i-2,j-2;r[i][j]=x9[oi][oj] if 0<=oi<len(x9) and 0<=oj<len(x9[0]) and x9[oi][oj] else 1
 return r