def p(g):
 x=[]
 for r in range(len(g)):
  for c in range(len(g[0])):
   if g[r][c]!=0 and g[r][c]!=5:x.append((r,c,g[r][c]))
 if len(x)!=4:return g
 x.sort()
 p=[(r,c)for r,c,z in x]
 a=min(r for r,c in p)
 b=max(r for r,c in p)
 d=min(c for r,c in p)
 e=max(c for r,c in p)
 if set(p)!={(a,d),(a,e),(b,d),(b,e)}:return g
 m={(r,c):z for r,c,z in x}
 o=[[0 for _ in range(len(g[0]))]for _ in range(len(g))]
 w=e-d
 h=b-a
 v=[m[(a,d)],m[(a,e)]]
 for i,j in[(0,0),(0,w),(h,0),(h,w)]:
  cr=a+i
  cc=d+j
  k=m[(cr,cc)]
  l=v[1]if k==v[0]else v[0]
  for dr in[-1,0,1]:
   for dc in[-1,0,1]:
    r,c=cr+dr,cc+dc
    if 0<=r<len(o)and 0<=c<len(o[0]):
     if dr==0 and dc==0:o[r][c]=k
     else:o[r][c]=l
 for dc in range(2,1+w//2,2):
  for r in[a,a+h]:
   if 0<=r<len(o)and 0<=d+dc<len(o[0]):o[r][d+dc]=5
   if 0<=r<len(o)and 0<=d+w-dc<len(o[0]):o[r][d+w-dc]=5
 for dr in range(2,1+h//2,2):
  for c in[d,d+w]:
   if 0<=a+dr<len(o)and 0<=c<len(o[0]):o[a+dr][c]=5
   if 0<=a+h-dr<len(o)and 0<=c<len(o[0]):o[a+h-dr][c]=5
 return o