def p(g):
 h,w=len(g),len(g[0]);ac=sum(g,[]);cc={};[cc.update({c:cc.get(c,0)+1})for c in ac];bg=max(cc,key=cc.get);v=[[0]*w for _ in range(h)];o=[]
 for i in range(h):
  for j in range(w):
   if not v[i][j] and g[i][j]!=bg:
    oc=[];s=[(i,j)]
    while s:
     ci,cj=s.pop()
     if ci<0 or ci>=h or cj<0 or cj>=w or v[ci][cj] or g[ci][cj]==bg:continue
     v[ci][cj]=1;oc.append((ci,cj));s.extend([(ci+di,cj+dj)for di,dj in[(0,1),(0,-1),(1,0),(-1,0)]])
    oc and o.append(frozenset((g[pos[0]][pos[1]],pos)for pos in oc))
 if not o:return g
 fo=o[0];pos=[pos for c,pos in fo]
 if not pos:return g
 mr,mc=min(p[0]for p in pos),min(p[1]for p in pos);no=frozenset((c,(pos[0]-mr,pos[1]-mc))for c,pos in fo);np=[pos for c,pos in no];ow=max(p[1]for p in np)+1 if np else 1;period=ow
 for p in range(1,ow):
  shifted=frozenset((c,(pos[0],pos[1]-p))for c,pos in no if pos[1]-p>=0)
  if shifted.issubset(no):period=p;break
 r=[r[:]for r in g]
 for c,(row,col) in fo:
  nc=col+period;0<=row<h and 0<=nc<w and r.__setitem__(row,r[row][:nc]+[c]+r[row][nc+1:])
 for c,(row,col) in fo:
  nc=col+3*period;0<=row<h and 0<=nc<w and r.__setitem__(row,r[row][:nc]+[c]+r[row][nc+1:])
 return r