def p(g):
 h,w=len(g),len(g[0]);c={};[[c.update({k:c.get(k,0)+1})for k in r]for r in g];lc=min(c,key=c.get);lp=[(i,j)for i in range(h)for j in range(w)if g[i][j]==lc];sp=[(i-1,j)for i,j in lp if i-1>=0];
 if not sp:return g
 mi=min(i for i,j in sp);mj1,mj2=min(j for i,j in sp if i==mi),max(j for i,j in sp if i==mi);ul,ur=(mi,mj1),(mi,mj2);r1,r2=[],[];i,j=ul;
 while 0<=i<h and 0<=j<w:r1.append((i,j));i-=1;j-=1
 i,j=ur
 while 0<=i<h and 0<=j<w:r2.append((i,j));i-=1;j+=1
 cr=set(r1+r2);bg=max(c,key=c.get);r=[r[:]for r in g]
 for ri,rj in cr:0<=ri<h and 0<=rj<w and r[ri][rj]==bg and r.__setitem__(ri,r[ri][:rj]+[lc]+r[ri][rj+1:])
 return r