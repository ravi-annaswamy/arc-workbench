def p(g):
 h,w=len(g),len(g[0]);ac=sum(g,[]);cc={};[cc.update({c:cc.get(c,0)+1})for c in ac];lc=min(cc,key=cc.get);lcp=[(i,j)for i in range(h)for j in range(w)if g[i][j]==lc]
 if not lcp:return g
 mr,Mr,mc,Mc=min(p[0]for p in lcp),max(p[0]for p in lcp),min(p[1]for p in lcp),max(p[1]for p in lcp);imr,iMr,imc,iMc=mr+1,Mr-1,mc+1,Mc-1;ibp=set()
 if imr<=iMr and imc<=iMc:
  for i in range(imr,iMr+1):ibp.update([(i,imc),(i,iMc)])
  for j in range(imc,iMc+1):ibp.update([(imr,j),(iMr,j)])
 to=frozenset((0,pos)for pos in ibp)
 if to:
  tp=[pos for col,pos in to];tmr,tmc=min(p[0]for p in tp),min(p[1]for p in tp);nt=frozenset((col,(pos[0]-tmr,pos[1]-tmc))for col,pos in to)
 else:nt=frozenset()
 op=[]
 if nt:
  tp=[pos for col,pos in nt];th,tw=(max(p[0]for p in tp)+1 if tp else 0),(max(p[1]for p in tp)+1 if tp else 0)
  for i in range(h-th+1):
   for j in range(w-tw+1):
    m=all(0<=i+ti<h and 0<=j+tj<w and g[i+ti][j+tj]==tcol for tcol,(ti,tj)in nt);m and op.append((i,j))
 nlp=[(pos[0]-mr,pos[1]-mc)for pos in lcp]if lcp else[];slp=[(pos[0]-1,pos[1]-1)for pos in nlp];fp=[]
 for oi,oj in op:
  for si,sj in slp:
   fi,fj=oi+si,oj+sj;0<=fi<h and 0<=fj<w and fp.append((fi,fj))
 r=[r[:]for r in g];[r.__setitem__(i,r[i][:j]+[lc]+r[i][j+1:])for i,j in fp]
 return r