def p(g):
 from itertools import combinations as C;h,w=len(g),len(g[0]);T=lambda r,c,i:[(r,c),(r,c+1),(r+1,c),(r+1,c+1)]if i<1 else[(r,c),(r+1,c),(r+2,c)]if i<2 else[(r,c),(r,c+1),(r,c+2)];A=[(r,c,i)for i in range(3)for r in range(h-(1,2,0)[i])for c in range(w-(1,0,2)[i])if all(0<=x<h and 0<=y<w and g[x][y]==5 for x,y in T(r,c,i))];G={(r,c)for r in range(h)for c in range(w)if g[r][c]==5};S=lambda L:len(P:=sum([T(r,c,i)for r,c,i in L],[]))==len(set(P))and set(P)==G;B=next((t for s in range(1,min(len(A)+1,10))for t in C(A,s)if S(t)),None)
 if not B:
  def F(R,Q,A):
   if not R:return Q
   for i,(r,c,x)in enumerate(A):
    P=set(T(r,c,x))
    if P&R and not P&set(sum([T(a,b,y)for a,b,y in Q],[])):
     if N:=F(R-P,Q+[(r,c,x)],A[i+1:]):return N
  B=F(G,[],A)or[]
 if not B:U,B=set(),[];[(B.append((r,c,i)),U.update(P))for r,c,i in sorted(A,key=lambda x:(x[2],x[0],x[1]))if not(P:=set(T(r,c,i)))&U]
 [g[x].__setitem__(y,8 if i<1 else 2)for r,c,i in B for x,y in T(r,c,i)if 0<=x<h and 0<=y<w];return g