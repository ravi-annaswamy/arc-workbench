z=lambda g:[*map(list,zip(*g[::-1]))]
def p(g):m=z(g);g=[g[r]+m[r] for r in range(len(g))];return g+z(z(g))