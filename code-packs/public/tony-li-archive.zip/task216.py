R=range
L=len
def p(a):
    n,m=L(a),L(a[0])
    M=A=T=D=B=K=0
    for t in R(n):
        s=[0]*m;z=[0]*m
        for b in R(t,n):
            s=[sj+(v==2) for sj,v in zip(s,a[b])]
            z=[zj+(v==0) for zj,v in zip(z,a[b])]
            c=l=0
            for j in R(m+1):
                if j<m and z[j]==0: c+=s[j]
                else:
                    w=j-l;u=(b-t+1)*w
                    if w and (c>M or (c==M and u>A)): M,A,T,D,B,K=c,u,t,l,b,j-1
                    l=j+1;c=0
    return [r[D:K+1] for r in a[T:B+1]] if A else []