E=enumerate
R=range
def p(a):
    b=[r[:] for r in a]
    t=[[i for i,v in E(r) if v==4] for r in a]
    for i,c in E(t):
        for j,x in E(c):
            for y in c[j+1:]:
                for k in R(i+1,len(a)):
                    if a[k][x]==4 and a[k][y]==4:
                        for q in R(i+1,k):
                            b[q][x+1:y]=[2]*(y-x-1)
    return b