def p(j):
 for A in j:A[::3]=[6 if v==4 else v for v in A[::3]]
 return j