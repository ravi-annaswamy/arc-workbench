p=lambda j:[[a and b and 2 for a,b in zip(r[:3],r[4:7])]for r in j[:3]]
