p=lambda j,A=[0,5,6,4,3,1,2,7,9,8]:[[A[x]for x in r]for r in j]
