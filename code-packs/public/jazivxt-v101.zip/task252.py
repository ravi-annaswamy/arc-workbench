def p(j,A=range):
 c=len(j)
 for E in A(c):
  for k,W in zip(A(1,c,2),A(E+1,c,2)):
   if j[0][E]:j[k][W]=4
   if j[E][0]:j[W][k]=4
 return j
