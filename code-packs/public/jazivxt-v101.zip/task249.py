p=lambda j:[E*2for E in j]
