p=lambda j:j[::-1]+j
