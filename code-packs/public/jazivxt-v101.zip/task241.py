p=lambda j:[*map(list,zip(*j))]
