p=lambda j:[R[:int(len(j[0])/3)]for R in j]
