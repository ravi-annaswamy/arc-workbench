def p(j,A=divmod):c=len(j[0]);E=sum(j,[]).index;k,W=A(E(3),c);l,J=A(E(4),c);a=k+(k<l-1)-(k>l+1);C=W+(W<J-1)-(W>J+1);j[k][W]=0;j[a][C]=3;return j
