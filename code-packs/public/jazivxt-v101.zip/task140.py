p=lambda g:[r[::-1]for r in g[::-1]]
