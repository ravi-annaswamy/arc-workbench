p=lambda j:[R+R[::-1]for R in j]
