p=lambda g:[[3if g[i][j]+g[i+7][j]==2else 0for j in range(5)]for i in range(6)]
