p=lambda j:[r[3%len(r):]+r[:3%len(r)]for r in j[2:]+j[:2]]
