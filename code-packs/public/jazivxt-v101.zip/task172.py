p=lambda j:j+j[::-1]
