p=lambda j:[[1if[j[i][0]for i in range(3)]==[j[i][2]for i in range(3)]else 7]]
