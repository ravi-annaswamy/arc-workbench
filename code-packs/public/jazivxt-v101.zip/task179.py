p=lambda g:list(map(list,zip(*g)))
